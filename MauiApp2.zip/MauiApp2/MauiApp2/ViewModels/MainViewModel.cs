﻿using System.Windows.Input;
using Microsoft.Maui.Controls;
using MauiApp2.Models;

namespace MauiApp2.ViewModels
{
    public class MainViewModel
    {
        public Car Car { get; }

        public string CarName => Car.Name;
        public string CarType => Car.Type;
        public string CarAddress => Car.Address;
        public string OwnerName => Car.OwnerName;
        public string OwnerRole => Car.OwnerRole;
        public string CarDescription => Car.Description;
        public string CarImage => Car.ImageFile;

        public ICommand LocationCommand { get; }
        public ICommand RentalCommand { get; }

        public MainViewModel()
        {
            Car = new Car
            {
                Name = "Toyota GT86",
                Type = "Sports Car",
                Address = "📍 88, Jalan Bukit Assek, 96000 Sibu, Sarawak",
                OwnerName = "Aiman Zaini",
                OwnerRole = "Owner",
                Description = "The Toyota GT86 delivers pure driving pleasure with its balanced handling and responsive power.",
                ImageFile = "gt86.jpg"
            };

            LocationCommand = new Command(OnLocationClicked);
            RentalCommand = new Command(OnRentalClicked);
        }

        private void OnLocationClicked()
        {
            Application.Current.MainPage?.DisplayAlert("Location", "Opening Google Maps...", "OK");
        }

        private void OnRentalClicked()
        {
            Application.Current.MainPage?.DisplayAlert("Rental", "Rental request sent!", "OK");
        }
    }
}
