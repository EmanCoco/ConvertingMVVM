[assembly: XmlnsDefinition("http://schemas.microsoft.com/dotnet/maui/global", "MauiApp2")]
[assembly: XmlnsDefinition("http://schemas.microsoft.com/dotnet/maui/global", "MauiApp2.Pages")]
